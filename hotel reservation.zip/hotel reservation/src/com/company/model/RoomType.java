package com.company.model;

public enum RoomType {
    SINGLE,
    DOUBLE
}
